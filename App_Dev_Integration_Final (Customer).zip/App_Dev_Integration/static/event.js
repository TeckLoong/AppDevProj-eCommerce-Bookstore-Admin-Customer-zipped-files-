window.onload = function() {
    var viewItem = sessionStorage.getItem("viewItem");  
    $('#viewSelect').val(viewItem);
    }
    $('#viewSelect').change(function() { 
        var viewVal = $(this).val();
        window.location = "/product/start=1&view=" + viewVal;
        sessionStorage.setItem("viewItem", viewVal);
    });

function deliverySearch() {
    filter = document.getElementById("delivery-search").value.toUpperCase();
    table = document.getElementById("delivery-table");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[0];
      if (td) {
        txtValue = td.textContent || td.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }       
    }
  }